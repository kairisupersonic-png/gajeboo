#!/usr/bin/env python3
"""
TitanX Testnet Bot v2 — TANPA BROWSER
=====================================
Buka/tutup posisi long/short random di semua market titanx testnet,
size = 75% saldo, Ed25519 session signing (replikasi persis frontend).

Instalasi:
    pip install requests cryptography

Token:
    .env sebelah script: TITANX_TOKEN=eyJ...   (access token, 24 jam)
    -> Ambil token baru: buka titanx login (F12 -> Network -> oauth/token -> Response),
       atau jalankan: python titanx_bot2.py set-token

Perintah:
    python titanx_bot2.py probe      # tes koneksi, daftar market, saldo
    python titanx_bot2.py dry        # simulasi siklus
    python titanx_bot2.py run        # jalankan beneran (Ctrl+C stop)
"""
import base64
import hashlib
import json
import os
import random
import sys
import time
from datetime import datetime, timezone, timedelta
from pathlib import Path

import requests
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

HERE = Path(__file__).parent
API = "https://testnet-api.titanx.cc"
ORIGIN = "https://testnet.titanx.cc"
AUD = "Daml-Perp-Request v=2"
ENV_FILE = HERE / ".env"
KEY_FILE = HERE / "session_key.bin"
SESSION_FILE = HERE / "session.json"

SIZE_PCT = 0.75
HOLD_MIN, HOLD_MAX = 60, 240
PAUSE_MIN, PAUSE_MAX = 120, 420


# ---------- env ----------
def load_env():
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())


def get_token() -> str:
    tok = os.environ.get("TITANX_TOKEN", "").strip()
    if not tok:
        sys.exit("TITANX_TOKEN kosong. Isi .env: TITANX_TOKEN=eyJ...")
    return tok


def save_env_key(key: str, value: str):
    lines = []
    if ENV_FILE.exists():
        lines = [l for l in ENV_FILE.read_text().splitlines() if not l.startswith(key + "=")]
    lines.append(f"{key}={value}")
    ENV_FILE.write_text("\n".join(lines) + "\n")


def log(m):
    print(f"[{datetime.now():%H:%M:%S}] {m}", flush=True)


# ---------- key & session ----------
def load_or_create_key() -> Ed25519PrivateKey:
    if KEY_FILE.exists():
        raw = KEY_FILE.read_bytes()
    else:
        priv = Ed25519PrivateKey.generate()
        raw = priv.private_bytes(serialization.Encoding.Raw,
                                 serialization.PrivateFormat.Raw,
                                 serialization.NoEncryption())
        KEY_FILE.write_bytes(raw)
    return Ed25519PrivateKey.from_private_bytes(raw)


def priv_to_hex(priv: Ed25519PrivateKey) -> str:
    return priv.public_key().public_bytes(
        serialization.Encoding.Raw, serialization.PublicFormat.Raw).hex()


def register_session(token: str, pub_hex: str) -> dict:
    """POST /v1/auth/session — daftarkan keypair baru, dapat sessionId."""
    expiry = (datetime.now(timezone.utc) + timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
    body = {
        "scheme": "jwt",
        "token": token,
        "sessionPubKey": pub_hex,
        "expiry": expiry,
        "maxNotional": "1000000.0000000000",
    }
    h = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": ORIGIN,
        "Referer": ORIGIN + "/",
        "User-Agent": os.environ.get("TITANX_UA", "Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Mobile Safari/537.36"),
        "accept-language": "en-US,en;q=0.9",
        "sec-ch-ua": '"Not:A-Brand";v="8", "Chromium";v="156", "Google Chrome";v="156"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
    }
    cookies = os.environ.get("TITANX_COOKIES", "").strip()
    if cookies:
        h["Cookie"] = cookies
    r = requests.post(f"{API}/v1/auth/session", json=body, headers=h, timeout=30)
    if r.status_code != 200:
        raise RuntimeError(f"register session gagal {r.status_code}: {r.text[:300]}")
    return r.json()


def get_session():
    """Pakai sessionId tersimpan; kalau tidak ada/expired, daftarkan baru."""
    priv = load_or_create_key()
    pub_hex = priv_to_hex(priv)
    if SESSION_FILE.exists():
        try:
            s = json.loads(SESSION_FILE.read_text())
            if s.get("pub") == pub_hex and s.get("sessionId"):
                return priv, s["sessionId"]
        except Exception:
            pass
    log("mendaftarkan session key baru...")
    token = get_token()
    try:
        s = register_session(token, pub_hex)
    except RuntimeError as e:
        log("register langsung gagal (403 Cloudflare) -> coba lewat browser (CDP)...")
        if "403" in str(e):
            res = register_via_browser(token, pub_hex)
            log(f"browser register: {res['status']} {res['body'][:200]}")
            if res["status"] != 200:
                sys.exit("register via browser juga gagal. Pastikan start-browser.bat jalan & sudah login di titanx.")
            s = json.loads(res["body"])
        else:
            raise
    SESSION_FILE.write_text(json.dumps({"sessionId": s.get("sessionId") or s.get("id"),
                                        "pub": pub_hex, "raw": s}))
    log(f"session OK: {SESSION_FILE.read_text()[:120]}")
    return priv, s.get("sessionId") or s.get("id")




# ---------- hybrid: one-time register via real browser (CDP) ----------
def register_via_browser(token, pub_hex):
    """Buka browser (CDP), jalankan fetch POST /v1/auth/session dari halaman titanx.
    Hanya dipakai sekali saat 403 dari requests. Butuh start-browser.bat jalan."""
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        sys.exit("pip install playwright  (sekali saja, hanya untuk register awal)")
    cdp = os.environ.get("CDP_URL", "http://127.0.0.1:9222")
    with sync_playwright() as p:
        browser = p.chromium.connect_over_cdp(cdp)
        ctx = browser.contexts[0]
        page = next((pg for pg in ctx.pages if "titanx.cc" in pg.url), None)
        if page is None:
            page = ctx.new_page()
            page.goto(ORIGIN + "/trade/btc-usdcx", wait_until="domcontentloaded")
            page.wait_for_timeout(5000)
        expiry = (datetime.now(timezone.utc) + timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%S.000Z")
        js = """
        async ({token, pub, expiry}) => {
          const r = await fetch('%s/v1/auth/session', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            credentials: 'include',
            body: JSON.stringify({scheme:'jwt', token, sessionPubKey: pub, expiry, maxNotional: '1000000.0000000000'})
          });
          const txt = await r.text();
          return {status: r.status, body: txt};
        }
        """ % API
        res = page.evaluate(js, {"token": token, "pub": pub_hex, "expiry": expiry})
        return res


# ---------- signing ----------
def H(k, v):
    return f"{k}: {v}"  # NOTE: request message uses single-space format (hn), NOT padded


def ts_iso(ms: int) -> str:
    dt = datetime.fromtimestamp(ms / 1000, timezone.utc)
    s = dt.strftime("%Y-%m-%dT%H:%M:%S.") + f"{ms % 1000:03d}Z"
    return s.rstrip("0").rstrip(".") if s[-4] == "." else s
    # keep simple: always 3 digits then trim zeros like JS W()


def fmt_ts(ms: int) -> str:
    dt = datetime.fromtimestamp(ms / 1000, timezone.utc)
    base = dt.strftime("%Y-%m-%dT%H:%M:%S")
    frac = f"{ms % 1000:03d}".rstrip("0")
    return base + (f".{frac}Z" if frac else "Z")


def query_canon(qs: str) -> str:
    """Replikasi fn() di JS: sort query params by encoded key."""
    if qs.startswith("?"):
        qs = qs[1:]
    if not qs:
        return ""
    parts = [p for p in qs.split("&") if p]
    def key(p):
        k = p.split("=", 1)[0]
        return k.encode()
    return "&".join(sorted(parts, key=key))


def build_message(session_id, method, path, query="", body=None) -> str:
    nonce = int(time.time() * 1000)
    body_sha = hashlib.sha256((body or "").encode()).hexdigest()
    lines = [
        AUD,
        H("aud", "rest"),
        H("origin", API),  # JS o() = API base URL (client b), NOT the site origin
        H("session", session_id),
        H("conn", ""),
        H("method", method.upper()),
        H("path", path),
        H("query", query_canon(query)),
        H("body", body_sha),
        H("ts", fmt_ts(nonce)),
        H("nonce", nonce),
        H("expires", ""),
    ]
    return "\n".join(lines), nonce


def headers_for(priv, session_id, method, path, query="", body=None, body_str=None):
    body_for_sig = body_str if body_str is not None else (json.dumps(body) if body is not None else None)
    msg, nonce = build_message(session_id, method, path, query, body_for_sig)
    sig = priv.sign(msg.encode()).hex()
    return {
        "X-Session-Id": session_id,
        "X-Request-Ts": fmt_ts(nonce),
        "X-Request-Nonce": str(nonce),
        "X-Request-Sig": sig,
        "Authorization": f"Bearer {os.environ.get('TITANX_TOKEN','')}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Origin": ORIGIN,
        "Referer": ORIGIN + "/",
        "User-Agent": os.environ.get("TITANX_UA", "Mozilla/5.0 (Linux; Android 16; Pixel 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Mobile Safari/537.36"),
        "accept-language": "en-US,en;q=0.9",
        "sec-ch-ua": '"Not:A-Brand";v="8", "Chromium";v="156", "Google Chrome";v="156"',
        "sec-ch-ua-mobile": "?1",
        "sec-ch-ua-platform": '"Android"',
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-site",
        "priority": "u=1, i",
    }


def api(priv, sid, method, path, query="", body=None):
    url = API + path + (f"?{query}" if query else "")
    data = json.dumps(body) if body is not None else None
    h = headers_for(priv, sid, method, path, query, body, body_str=data)
    cookies = os.environ.get("TITANX_COOKIES", "").strip()
    if cookies:
        h["Cookie"] = cookies
    r = requests.request(method, url, headers=h, data=data, timeout=30)
    return r


# ---------- trading ----------
def get_markets(priv, sid):
    r = api(priv, sid, "GET", "/v1/markets")
    if r.status_code != 200:
        return []
    d = r.json()
    return d.get("markets", d if isinstance(d, list) else [])


def get_balance(priv, sid):
    r = api(priv, sid, "GET", "/v1/me/balance")
    if r.status_code != 200:
        log(f"balance {r.status_code}: {r.text[:150]}")
        return None
    return float(r.json().get("freeBalance") or r.json().get("balance") or 0)


def get_positions(priv, sid):
    r = api(priv, sid, "GET", "/v1/me/positions")
    if r.status_code != 200:
        return []
    d = r.json()
    return d.get("items", d if isinstance(d, list) else [])


def get_mark_price(priv, sid, market):
    """Harga mark dari /v1/markets/{M}/mark (endpoint asli dari HAR)."""
    r = api(priv, sid, "GET", f"/v1/markets/{market}/mark")
    if r.status_code == 200:
        try:
            d = r.json()
            if isinstance(d, dict):
                for k in ("markPrice", "price", "mid", "last"):
                    if d.get(k):
                        return float(d[k])
                if d.get("mark") and isinstance(d["mark"], dict):
                    for k in ("price", "markPrice", "mid"):
                        if d["mark"].get(k):
                            return float(d["mark"][k])
        except Exception:
            pass
    log(f"gagal ambil harga mark {market}: {r.status_code} {r.text[:120]}")
    return None


def canon_dec(x: str) -> str:
    """Replikasi U() di JS: decimal -> X.XXXXXXXXXX (10 digit pecahan)."""
    x = str(x).strip()
    neg, rest = ("-", x[1:]) if x.startswith("-") else ("", x)
    if "." in rest:
        i, f = rest.split(".", 1)
    else:
        i, f = rest, ""
    f = (f + "0" * 10)[:10]
    i = i.lstrip("0") or "0"
    if i == "0" and set(f) <= {"0"}:
        return "0.0000000000"
    return f"{neg}{i}.{f}"


def Hp(k, v):
    return f"{k}:".ljust(14) + str(v)


def order_headers(priv, session_id, market, order, nonce, ts_str):
    """Header order: X-Session-Sig atas pesan 'Daml-Perp-Order v=1'."""
    lines = [
        "Daml-Perp-Order v=1",
        Hp("sessionId", session_id),
        Hp("market", market),
        Hp("side", order["side"]),
        Hp("type", order["type"]),
        Hp("size", canon_dec(order["size"])),
        Hp("price", canon_dec(order.get("price", "0"))),
        Hp("tif", order.get("tif", "") or ""),
        Hp("reduceOnly", "true" if order.get("reduceOnly") is True else "false"),
        Hp("tpTrigger", canon_dec("0")),
        Hp("tpLimit", canon_dec("0")),
        Hp("tpSize", canon_dec("0")),
        Hp("slTrigger", canon_dec("0")),
        Hp("slLimit", canon_dec("0")),
        Hp("slSize", canon_dec("0")),
        Hp("clientOrderId", ""),
        Hp("nonce", nonce),
        Hp("ts", ts_str),
    ]
    msg = "\n".join(lines)
    return {
        "X-Session-Id": session_id,
        "X-Session-Sig": priv.sign(msg.encode()).hex(),
    }


def place_order(priv, sid, market, side, size_str, mkt_meta, reduce_only=False):
    nonce = int(time.time() * 1000)
    ts_str = fmt_ts(nonce)
    order = {"side": side, "type": "market", "size": size_str,
             "price": "0", "tif": "ioc", "reduceOnly": reduce_only}
    body = {
        "market": market,
        **{k: v for k, v in order.items() if not (k == "tif" and v == "")},
        "nonce": nonce,
        "ts": ts_str,
    }
    h = headers_for(priv, sid, "POST", "/v1/orders", body=body, body_str=json.dumps(body))
    h.update(order_headers(priv, sid, market, order, nonce, ts_str))
    data = json.dumps(body)
    r = requests.post(f"{API}/v1/orders", headers=h, data=data, timeout=30)
    ok = r.status_code in (200, 201)
    log(f"{'✓' if ok else '✗'} ORDER {side.upper()} {market} size={size_str} -> {r.status_code} {r.text[:150]}")
    return ok


# ---------- trading ----------
def round_size(x: float, dec: int) -> str:
    """Bulatkan size ke szDecimals market, return string."""
    q = round(x, dec)
    if q <= 0:
        q = 10 ** -dec  # minimal 1 unit terkecil
    return f"{q:.{dec}f}"


MARKET_CACHE = []


def close_all(priv, sid):
    closed = 0
    for p in get_positions(priv, sid):
        market = p.get("market")
        size = abs(float(p.get("size", 0)))
        is_long = float(p.get("size", 0)) > 0
        side = "sell" if is_long else "buy"
        meta = next((m for m in MARKET_CACHE if m.get("market") == market), {})
        dec = int(meta.get("szDecimals", 4))
        ok = place_order(priv, sid, market, side, round_size(size, dec), meta, reduce_only=True)
        if ok:
            closed += 1
        time.sleep(1.5)
    return closed


def cycle(priv, sid, dry=False):
    global MARKET_CACHE
    markets = get_markets(priv, sid)
    if not markets:
        log("tidak bisa ambil markets")
        return False
    MARKET_CACHE = markets

    bal = get_balance(priv, sid)
    if bal is None:
        return False

    m = random.choice(markets)
    market = m.get("market")
    dec = int(m.get("szDecimals", 4))
    min_notional = float(m.get("minNotional", 10))

    price = get_mark_price(priv, sid, market)
    if not price or price <= 0:
        log("harga tidak terbaca — siklus dilewati (ini penyebab notional_cap kemarin)")
        return False
    notional = max(bal * SIZE_PCT, min_notional)
    size = notional / price
    size_str = round_size(size, dec)

    side = random.choice(["buy", "sell"])
    pos_side = "LONG" if side == "buy" else "SHORT"
    log(f"saldo ${bal:.2f} | {market} {pos_side} notional=${notional:.2f} size={size_str} (harga {price})")

    if dry:
        log("[DRY] tidak kirim order")
        return True

    ok = place_order(priv, sid, market, side, size_str, m)
    if not ok:
        return False

    hold = random.randint(HOLD_MIN, HOLD_MAX)
    log(f"menahan posisi {hold}s ...")
    time.sleep(hold)
    n = close_all(priv, sid)
    log(f"posisi ditutup: {n}")
    return True


# ---------- commands ----------
def cmd_probe(priv, sid):
    log("=== PROBE ===")
    r = api(priv, sid, "GET", "/v1/markets")
    log(f"GET /v1/markets -> {r.status_code}")
    if r.status_code == 200:
        ms = r.json().get("markets", [])
        for m in ms:
            log(f"  {m.get('market'):12} szDec={m.get('szDecimals')} minNotional={m.get('minNotional')} maxLev={m.get('maxLeverage')}")
    r = api(priv, sid, "GET", "/v1/me/balance")
    log(f"GET /v1/me/balance -> {r.status_code} {r.text[:200]}")
    r = api(priv, sid, "GET", "/v1/me/positions")
    log(f"GET /v1/me/positions -> {r.status_code} {r.text[:200]}")


def cmd_set_token():
    print("Paste access token (jwt, eyJ...):")
    tok = input().strip()
    if tok:
        save_env_key("TITANX_TOKEN", tok)
        SESSION_FILE.unlink(missing_ok=True)
        print("token disimpan, session di-reset. Jalankan: python titanx_bot2.py probe")


def main():
    load_env()
    cmd = sys.argv[1] if len(sys.argv) > 1 else "run"

    if cmd == "set-token":
        cmd_set_token()
        return

    priv, sid = get_session()

    if cmd == "probe":
        cmd_probe(priv, sid)
    elif cmd == "dry":
        cycle(priv, sid, dry=True)
    elif cmd == "run":
        log("=== TitanX Bot v2 (tanpa browser) ===")
        # tutup posisi lama yang masih kebuka sebelum mulai
        try:
            n = close_all(priv, sid)
            if n:
                log(f"posisi lama ditutup saat mulai: {n}")
        except Exception as e:
            log(f"gagal cek/tutup posisi lama: {e}")
        while True:
            try:
                cycle(priv, sid)
            except KeyboardInterrupt:
                log("stop (Ctrl+C) — menutup posisi...")
                close_all(priv, sid)
                return
            except Exception as e:
                log(f"error: {e}")
                # session kadang invalid -> daftar ulang
                if "401" in str(e) or "unauthorized" in str(e).lower():
                    SESSION_FILE.unlink(missing_ok=True)
                    priv, sid = get_session()
            nap = random.randint(PAUSE_MIN, PAUSE_MAX)
            log(f"jeda {nap}s\n")
            time.sleep(nap)
    else:
        print(__doc__)


if __name__ == "__main__":
    main()
